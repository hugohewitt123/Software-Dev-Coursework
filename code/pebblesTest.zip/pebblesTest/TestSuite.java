import org.junit.runner.RunWith;
import org.junit.runners.Suite;

//Test suite to run the tests
@RunWith(Suite.class)
@Suite.SuiteClasses({PebbleGameTest.class, BagTest.class})
public class TestSuite {
    //empty
}